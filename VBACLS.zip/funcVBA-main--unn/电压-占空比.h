#include <stdio.h>
 
// 定义电压-占空比映射表结构
typedef struct {
    float input_voltage;   // 输入电压 (V)
    float duty_cycle;      // 对应的占空比 (0.0 ~ 1.0)
} VoltageDutyTable;
 
// 电压-占空比查找表 (示例数据)
const VoltageDutyTable duty_table[] = {
    {5.0f,  0.40f},
    {6.0f,  0.33f},
    {7.0f,  0.29f},
    {8.0f,  0.25f},
    {9.0f,  0.22f},
    {10.0f, 0.20f},
    {12.0f, 0.17f},
    {15.0f, 0.13f},
    {20.0f, 0.10f}
};
 
// 计算数组元素个数（总字节数 / 单个元素字节数）
#define TABLE_SIZE (sizeof(duty_table) / sizeof(duty_table[0]))
 
int main() {
    // 打印表头
    printf("输入电压 (V) | 占空比 (%%)\n");
    printf("-------------------------\n");
    
    // 遍历数组并打印每个元素
    for (int i = 0; i < TABLE_SIZE; i++) {
        // 占空比乘以100转换为百分比显示
        printf("%.1f         | %.2f%%\n", 
               duty_table[i].input_voltage, 
               duty_table[i].duty_cycle * 100);
    }
    
    return 0;
}