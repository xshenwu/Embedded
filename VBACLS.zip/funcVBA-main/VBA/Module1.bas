Attribute VB_Name = "Module1"
Option Explicit

Sub AddButtonAndCode()
Attribute AddButtonAndCode.VB_Description = "Macro recorded 12/17/1998 by John Walkenbach"
Attribute AddButtonAndCode.VB_ProcData.VB_Invoke_Func = " \n14"
    Dim NewSheet As Worksheet
    Dim NewButton As OLEObject
    Dim Code As String
    Dim NextLine As Long
    Dim x
    
'   Make sure access to the VBProject is allowed
    On Error Resume Next
    Set x = ActiveWorkbook.VBProject
    If Err <> 0 Then
        MsgBox "Your security settings do not allow this macro to run.", vbCritical
        On Error GoTo 0
        Exit Sub
    End If

'   Add the sheet
    Set NewSheet = Sheets.Add
    
'   Add a CommandButton
    Set NewButton = NewSheet.OLEObjects.Add _
      ("Forms.CommandButton.1")
    With NewButton
        .Left = 4
        .Top = 4
        .Width = 150
        .Height = 36
        .Object.Caption = "Return to Sheet1"
    End With
    
'   Add the event handler code
    Code = "Sub CommandButton1_Click()" & vbNewLine
    Code = Code & "    On Error Resume Next" & vbNewLine
    Code = Code & "    Sheets(""Sheet1"").Activate" & vbNewLine
    Code = Code & "    If Err <> 0 Then" & vbNewLine
    Code = Code & "      MsgBox ""Cannot activate Sheet1.""" & vbNewLine
    Code = Code & "    End If" & vbNewLine
    Code = Code & "End Sub"
    
    With ActiveWorkbook.VBProject. _
      VBComponents(NewSheet.Name).CodeModule
        NextLine = .CountOfLines + 1
        .InsertLines NextLine, Code
    End With
End Sub
Option Explicit
Sub Create_TOC()
Dim wbBook As Workbook
Dim wsActive As Worksheet
Dim wsSheet As Worksheet
Dim lnRow As Long
Dim lnPages As Long
Dim lnCount As Long
Set wbBook = ActiveWorkbook
With Application
    .DisplayAlerts = False
    .ScreenUpdating = False
End With
'If the TOC sheet already exist delete it and add a new
'worksheet.
On Error Resume Next
With wbBook
    .Worksheets("TOC").Delete
    .Worksheets.Add Before:=.Worksheets(1)
End With
On Error GoTo 0
Set wsActive = wbBook.ActiveSheet
With wsActive
    .Name = "TOC"
    With .Range("A1:B1")
        .Value = VBA.Array("Table of Contents", "Sheet # - # of Pages")
        .Font.Bold = True
    End With
End With
lnRow = 2
lnCount = 1
'Iterate through the worksheets in the workbook and create
'sheetnames, add hyperlink and count & write the running number
'of pages to be printed for each sheet on the TOC sheet.
For Each wsSheet In wbBook.Worksheets
    If wsSheet.Name <> wsActive.Name Then
        wsSheet.Activate
        With wsActive
            .Hyperlinks.Add .Cells(lnRow, 1), "", _
            SubAddress:="'" & wsSheet.Name & "'!A1", _
            TextToDisplay:=wsSheet.Name
            lnPages = wsSheet.PageSetup.Pages().Count
            .Cells(lnRow, 2).Value = "'" & lnCount & "-" & lnPages
        End With
        lnRow = lnRow + 1
        lnCount = lnCount + 1
    End If
Next wsSheet
wsActive.Activate
wsActive.Columns("A:B").EntireColumn.AutoFit
With Application
    .DisplayAlerts = True
    .ScreenUpdating = True
End With
End Sub

